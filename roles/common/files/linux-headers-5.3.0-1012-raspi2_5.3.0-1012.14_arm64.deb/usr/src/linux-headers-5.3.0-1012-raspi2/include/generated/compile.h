/* This file is auto generated, version 14 */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#14 SMP Fri Nov 22 11:34:42 UTC 2019"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "metis"
#define LINUX_COMPILER "gcc version 9.2.1 20191008 (Ubuntu 9.2.1-9ubuntu2)"
